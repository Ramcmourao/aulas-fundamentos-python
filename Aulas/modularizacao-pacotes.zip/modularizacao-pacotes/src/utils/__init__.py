from time import sleep

def delay(time: int) -> None:
    sleep(time)


def pausa(txt: str) -> None:
    input(txt)


def cabecalho(txt: str) -> None:
    print('-' * len(txt))
    print(txt)
    print('-' * len(txt))


def menu() -> None:
    while True:
        cabecalho('MENU')
        print('[ 1 ] Adicionar notas')
        print('[ 2 ] Mostrar notas')
        print('[ 3 ] Apagar notas')
        print('[ 4 ] Pesquisar notas')
        print('[ 5 ] Sair')
        opcao = int(input('---> '))

        match opcao:
            case 1:
                cabecalho('ADICIONAR NOTA')
            case 2:
                cabecalho('MOSTRAR NOTAS')
            case 3:
                cabecalho('APAGAR NOTAS')
            case 4:
                cabecalho('PESQUISAR NOTAS')
            case 5:
                break

        pausa('---ENTER para continuar---')