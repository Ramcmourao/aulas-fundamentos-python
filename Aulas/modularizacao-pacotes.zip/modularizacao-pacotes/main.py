from src import utils

def main():
    utils.menu()

if __name__ == '__main__':
    main()